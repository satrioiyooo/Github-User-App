package com.example.submissionfund2.data.response

data class UserResponse (
    val id : Int,
    var login: String,
    var avatar_url: String,
)